-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 05, 2024 at 07:46 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `app2`
--

CREATE TABLE IF NOT EXISTS `app2` (
  `gen` varchar(50) DEFAULT NULL,
  `nal` varchar(50) DEFAULT NULL,
  `rel` varchar(50) DEFAULT NULL,
  `caste` varchar(50) DEFAULT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `fnum` int(11) DEFAULT NULL,
  `fano` varchar(20) NOT NULL,
  `fincome` int(11) DEFAULT NULL,
  `mname` varchar(50) DEFAULT NULL,
  `mano` varchar(50) DEFAULT NULL,
  `rplace` varchar(50) DEFAULT NULL,
  `fg` varchar(50) DEFAULT NULL,
  `farmer` varchar(30) DEFAULT NULL,
  `exser` varchar(30) DEFAULT NULL,
  `nico` varchar(30) DEFAULT NULL,
  `sp` varchar(30) DEFAULT NULL,
  `pc` varchar(30) DEFAULT NULL,
  `hr` varchar(30) DEFAULT NULL,
  `vito` varchar(50) DEFAULT NULL,
  `doorno` varchar(50) DEFAULT NULL,
  `pcode` int(11) DEFAULT NULL,
  `ciity` varchar(100) DEFAULT NULL,
  `statement` varchar(100) DEFAULT NULL,
  `conname` varchar(100) DEFAULT NULL,
  `comdoor` varchar(100) DEFAULT NULL,
  `comarea` varchar(100) DEFAULT NULL,
  `compncode` int(11) DEFAULT NULL,
  `comcity` varchar(100) DEFAULT NULL,
  `comstatement` varchar(100) DEFAULT NULL,
  `comconname` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`fano`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app2`
--

INSERT INTO `app2` (`gen`, `nal`, `rel`, `caste`, `fname`, `fnum`, `fano`, `fincome`, `mname`, `mano`, `rplace`, `fg`, `farmer`, `exser`, `nico`, `sp`, `pc`, `hr`, `vito`, `doorno`, `pcode`, `ciity`, `statement`, `conname`, `comdoor`, `comarea`, `compncode`, `comcity`, `comstatement`, `comconname`) VALUES
('Male', '', '', '1', '', 0, '', 0, '1', '1', '', 'YES', 'NO', 'NO', 'NO', 'NO', 'NO', 'NO', '1', '1', 1, '1', '1', '1', '1', '1', 0, '1', '', '1'),
('Male', 'INDIAN', 'HINDU', '2', '2', 2, '2', 2, '2', '2', 'CORPORATION', 'YES', 'NO', 'NO', 'NO', 'NO', 'NO', 'NO', '2', '2', 2, '2', '2', '2', '2', '2', 2, '2', '22', '2'),
('Male', 'INDIAN', 'HINDU', '3', '3', 3, '3', 33, '3', '3', 'CORPORATION', 'YES', 'NO', 'NO', 'NO', 'NO', 'NO', 'NO', '3', '33', 33, '3', '3', '3', '3', '3', 3, '3', '3', '3'),
('Male', 'INDIAN', 'HINDU', '4', '4', 4, '4', 44, '4', '4', 'CORPORATION', 'YES', 'NO', 'NO', 'NO', 'NO', 'NO', 'NO', '4', '4', 4, '4', '4', '4', '4', '4', 4, '4', '4', '4');

-- --------------------------------------------------------

--
-- Table structure for table `app3`
--

CREATE TABLE IF NOT EXISTS `app3` (
  `insname` varchar(100) DEFAULT NULL,
  `board` varchar(30) DEFAULT NULL,
  `marks` int(11) DEFAULT NULL,
  `obmarks` int(11) DEFAULT NULL,
  `year` varchar(30) DEFAULT NULL,
  `insname1` varchar(100) DEFAULT NULL,
  `board1` varchar(30) DEFAULT NULL,
  `marks1` int(11) DEFAULT NULL,
  `obmarks1` int(11) DEFAULT NULL,
  `year1` varchar(30) DEFAULT NULL,
  `board2` varchar(30) DEFAULT NULL,
  `scname` varchar(100) DEFAULT NULL,
  `emisno` varchar(50) DEFAULT NULL,
  `year2` varchar(50) DEFAULT NULL,
  `regno` varchar(50) DEFAULT NULL,
  `medium` varchar(50) DEFAULT NULL,
  `sub1` varchar(50) DEFAULT NULL,
  `ms1` int(11) DEFAULT NULL,
  `att1` varchar(50) DEFAULT NULL,
  `sub2` varchar(50) DEFAULT NULL,
  `ms2` int(11) DEFAULT NULL,
  `att2` varchar(50) DEFAULT NULL,
  `sub3` varchar(50) DEFAULT NULL,
  `ms3` int(11) DEFAULT NULL,
  `att3` varchar(50) DEFAULT NULL,
  `sub4` varchar(50) DEFAULT NULL,
  `ms4` int(11) DEFAULT NULL,
  `att4` varchar(50) DEFAULT NULL,
  `sub5` varchar(50) DEFAULT NULL,
  `ms5` int(11) DEFAULT NULL,
  `att5` varchar(50) DEFAULT NULL,
  `sub6` varchar(50) DEFAULT NULL,
  `ms6` int(11) DEFAULT NULL,
  `att6` varchar(50) DEFAULT NULL,
  `secmar` int(11) DEFAULT NULL,
  `permar` int(11) DEFAULT NULL,
  `ctmar` int(11) DEFAULT NULL,
  `perctmar` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app3`
--

INSERT INTO `app3` (`insname`, `board`, `marks`, `obmarks`, `year`, `insname1`, `board1`, `marks1`, `obmarks1`, `year1`, `board2`, `scname`, `emisno`, `year2`, `regno`, `medium`, `sub1`, `ms1`, `att1`, `sub2`, `ms2`, `att2`, `sub3`, `ms3`, `att3`, `sub4`, `ms4`, `att4`, `sub5`, `ms5`, `att5`, `sub6`, `ms6`, `att6`, `secmar`, `permar`, `ctmar`, `perctmar`) VALUES
('2', 'TN STATE BOARD', 2, 2, '2017', '2', 'TN STATE BOARD', 2, 2, '2017', 'TN STATE BOARD', '2', '2', '2018', '2', 'English', 'Tamil', 2, '1', 'English', 2, '1', 'Computer Science', 2, '1', 'Chemistry', 2, '1', 'Physics', 22, '1', 'Mathematics', 2, '1', 2, 2, 22, 2);
